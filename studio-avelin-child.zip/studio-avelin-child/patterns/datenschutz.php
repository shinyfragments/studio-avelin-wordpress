<?php
/**
 * Title: Datenschutzerklärung (Standard)
 * Slug: studio-avelin-child/datenschutz
 * Categories: featured, text
 * Description: Vorlage für die DSGVO-konforme Datenschutzerklärung von Studio Avelin
 */
?>
<!-- wp:group {"align":"wide","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide">
	<!-- wp:heading {"level":1} -->
	<h1 class="wp-block-heading">Datenschutzerklärung</h1>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"fontSize":"small"} -->
	<p class="has-small-font-size"><em>Stand: <?php echo date('m/Y'); ?></em></p>
	<!-- /wp:paragraph -->

	<!-- wp:separator {"className":"is-style-wide"} -->
	<hr class="wp-block-separator has-alpha-channel-opacity is-style-wide"/>
	<!-- /wp:separator -->

	<!-- wp:heading {"level":2} -->
	<h2 class="wp-block-heading">1. Datenschutz auf einen Blick</h2>
	<!-- /wp:heading -->

	<!-- wp:heading {"level":3} -->
	<h3 class="wp-block-heading">Allgemeine Hinweise</h3>
	<!-- /wp:heading -->
	<!-- wp:paragraph -->
	<p>Die folgenden Hinweise geben einen einfachen Überblick darüber, was mit Ihren personenbezogenen Daten passiert, wenn Sie unsere Website besuchen. Personenbezogene Daten sind alle Daten, mit denen Sie persönlich identifiziert werden können.</p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"level":3} -->
	<h3 class="wp-block-heading">Verantwortliche Stelle</h3>
	<!-- /wp:heading -->
	<!-- wp:paragraph -->
	<p>Die verantwortliche Stelle für die Datenverarbeitung auf dieser Website ist:</p>
	<!-- /wp:paragraph -->
	<!-- wp:paragraph -->
	<p><strong>Studio Avelin</strong><br>Michael Fiebus<br>E-Mail: hello@studio-avelin.com</p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"level":2} -->
	<h2 class="wp-block-heading">2. Hosting &amp; Infrastruktur</h2>
	<!-- /wp:heading -->
	<!-- wp:paragraph -->
	<p>Wir hosten die Inhalte unserer Website bei folgendem Anbieter:</p>
	<!-- /wp:paragraph -->
	<!-- wp:paragraph -->
	<p><strong>IONOS SE</strong><br>Elgendorfer Str. 57, 56410 Montabaur, Deutschland.<br>Details entnehmen Sie der Datenschutzerklärung von IONOS: <a href="https://www.ionos.de/schutz-datenschutz" target="_blank" rel="noreferrer noopener">https://www.ionos.de/schutz-datenschutz</a>.</p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"level":2} -->
	<h2 class="wp-block-heading">3. Rechte der betroffenen Personen</h2>
	<!-- /wp:heading -->
	<!-- wp:paragraph -->
	<p>Sie haben jederzeit das Recht, unentgeltlich Auskunft über Herkunft, Empfänger und Zweck Ihrer gespeicherten personenbezogenen Daten zu erhalten. Sie haben außerdem ein Recht, die Berichtigung oder Löschung dieser Daten zu verlangen.</p>
	<!-- /wp:paragraph -->

	<!-- wp:paragraph -->
	<p>Hierzu sowie zu weiteren Fragen zum Thema Datenschutz können Sie sich jederzeit unter der im Impressum angegebenen Adresse an uns wenden.</p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
